Asset Pro Documentation:

This is the documentation for how to install and run this project.

Pre-Requisites:
npm
mongodb
mongosh

Run the following command to start the application
npm server.js
Then navigate to localhost:3000 to start the application.

