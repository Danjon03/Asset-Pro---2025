function loadButtons()
{
          // Load and parse the logged-in user
          const rawUser = localStorage.getItem('loggedInUserID');
          const user = JSON.parse(rawUser);
          const name = user.firstName;
          const permissions = user.permissions;
    
          //Defines the buttons we are creating
          const menuItems = [
            { key: 'createAsset', label: 'Create' },
            { key: 'editAsset', label: 'Edit' },
            { key: 'fillAsset', label: 'Fill' }
          ];
    
          const container = document.querySelector('.asset-button-row');
    
          menuItems.forEach(item => {
            // Always show non-admin; admin only if user.permissions includes 'is_admin'
            if ((item.key == 'createAsset' || item.key == 'editAsset') && permissions.canCreateAssets == true) {
              const btn = document.createElement('button');
              btn.classList.add('asset-btn');
              btn.textContent = item.label;
              btn.addEventListener('click', () => navigateTo(item.key));
              container.appendChild(btn);
            }
            else if (item.key == 'fillAsset' && permissions.canFillAsset == true) {
              const btn = document.createElement('button');
              btn.classList.add('asset-btn');
              btn.textContent = item.label;
              btn.addEventListener('click', () => navigateTo(item.key));
              container.appendChild(btn);
            }
    
          });
}